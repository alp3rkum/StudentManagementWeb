package com.j01.StudentManagementWeb.Business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.j01.StudentManagementWeb.DataAccessLayer.IStudentDal;
import com.j01.StudentManagementWeb.Entities.Student;

@Service
public class StudentManager implements IStudentService {

	private IStudentDal _studentDal;
	
	public StudentManager(IStudentDal studentDal) {
		//super();
		this._studentDal = studentDal;
	}

	@Override
	@Autowired
	@Transactional
	public List<Student> getAll() {
		//TODO business rules
		return this._studentDal.getAll();
	}
	
	@Override
	@Transactional
	public Student getById(int id) {
		//TODO business rules
		return this._studentDal.getById(id);
	}
	
	public Student getByStudentID(int studentID) {
		return this._studentDal.getByStudentId(studentID);
	}

	@Override
	@Transactional
	public void add(Student student) {
		this._studentDal.add(student);
	}

	@Override
	@Transactional
	public void update(Student student) {
		//TODO business rules
		this._studentDal.update(student);
	}

	@Override
	@Transactional
	public void delete(Student student) {
		//TODO business rules
		this._studentDal.delete(student);
	}

}
